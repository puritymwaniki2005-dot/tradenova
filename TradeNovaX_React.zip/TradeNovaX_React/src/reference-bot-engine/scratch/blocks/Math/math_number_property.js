import { localize } from '@deriv-com/translations';
import { modifyContextMenu } from '../../utils';

window.Blockly.Blocks.math_number_property = {
    init() {
        this.jsonInit(this.definition());

        this.setOnChange(event => {
            if (event.name === 'PROPERTY') {
                const hasDivisorInput = this.getFieldValue('PROPERTY') === 'DIVISIBLE_BY';
                this.updateShape(hasDivisorInput);
            }
        });
    },
    definition() {
        return {
            message0: localize('{{ number }} is {{ type }}', {
                number: '%1',
                type: '%2',
            }),
            args0: [
                {
                    type: 'input_value',
                    name: 'NUMBER_TO_CHECK',
                },
                {
                    type: 'field_dropdown',
                    name: 'PROPERTY',
                    options: [
                        ['even', 'EVEN'],
                        ['odd', 'ODD'],
                        ['prime', 'PRIME'],
                        ['whole', 'WHOLE'],
                        ['positive', 'POSITIVE'],
                        ['negative', 'NEGATIVE'],
                        ['divisible by', 'DIVISIBLE_BY'],
                    ],
                },
            ],
            output: 'Boolean',
            outputShape: window.Blockly.OUTPUT_SHAPE_ROUND,
            colour: window.Blockly.Colours.Base.colour,
            colourSecondary: window.Blockly.Colours.Base.colourSecondary,
            colourTertiary: window.Blockly.Colours.Base.colourTertiary,
            toolip: localize('This block tests a given number according to the selection'),
            category: window.Blockly.Categories.Mathematical,
        };
    },
    meta() {
        return {
            display_name: localize('Test a number'),
            description: localize(
                'This block tests a given number according to the selection and it returns a value of “True” or “False”. Available options: Even, Odd, Prime, Whole, Positive, Negative, Divisible'
            ),
        };
    },
    domToMutation(xmlElement) {
        const hasDivisorInput = xmlElement.getAttribute('divisor_input') === 'true';
        this.updateShape(hasDivisorInput);
    },
    mutationToDom() {
        const container = document.createElement('mutation');
        const divisorInput = this.getFieldValue('PROPERTY') === 'DIVISIBLE_BY';
        container.setAttribute('divisor_input', divisorInput);
        return container;
    },
    updateShape(hasDivisorInput) {
        if (hasDivisorInput) {
            const inputExists = this.getInput('DIVISOR');
            if (inputExists) {
                this.removeInput('DIVISOR');
            } else {
                this.appendValueInput('DIVISOR').setCheck('Number');
                this.initSvg();
                this.renderEfficiently();
            }
        }
    },
    customContextMenu(menu) {
        modifyContextMenu(menu);
    },
    getRequiredValueInputs() {
        return {
            NUMBER_TO_CHECK: null,
        };
    },
};

window.Blockly.JavaScript.javascriptGenerator.forBlock.math_number_property = block => {
    const argument0 =
        window.Blockly.JavaScript.javascriptGenerator.valueToCode(
            block,
            'NUMBER_TO_CHECK',
            window.Blockly.JavaScript.javascriptGenerator.ORDER_MODULUS
        ) || '0';
    const property = block.getFieldValue('PROPERTY');

    let code;

    if (property === 'PRIME') {
        // eslint-disable-next-line no-underscore-dangle
        const functionName = window.Blockly.JavaScript.javascriptGenerator.provideFunction_('mathIsPrime', [
            // eslint-disable-next-line no-underscore-dangle
            `function ${window.Blockly.JavaScript.FUNCTION_NAME_PLACEHOLDER_}(n) {
                // https://en.wikipedia.org/wiki/Primality_test#Naive_methods
                if (n == 2 || n == 3) {
                    return true;
                }

                // False if n is NaN, negative, is 1, or not whole.
                // And false if n is divisible by 2 or 3.
                if (isNaN(n) || n <= 1 || n % 1 != 0 || n % 2 == 0 || n % 3 == 0) {
                    return false;
                }

                // Check all the numbers of form 6k +/- 1, up to sqrt(n).
                for (var x  = 6; x <= Math.sqrt(n) + 1; x += 6) {
                    if (n % (x - 1) == 0 || n % (x + 1) == 0) {
                        return false;
                    }
                }
                return true;
            }`,
        ]);
        code = `${functionName}(${argument0})`;
        return [code, window.Blockly.JavaScript.javascriptGenerator.ORDER_FUNCTION_CALL];
    } else if (property === 'EVEN') {
        code = `${argument0} % 2 === 0`;
    } else if (property === 'ODD') {
        code = `${argument0} % 2 === 1`;
    } else if (property === 'WHOLE') {
        code = `${argument0} % 1 === 0`;
    } else if (property === 'POSITIVE') {
        code = `${argument0} > 0`;
    } else if (property === 'NEGATIVE') {
        code = `${argument0} < 0`;
    } else if (property === 'DIVISIBLE_BY') {
        const divisor =
            window.Blockly.JavaScript.javascriptGenerator.valueToCode(
                block,
                'DIVISOR',
                window.Blockly.JavaScript.javascriptGenerator.ORDER_MODULUS
            ) || '0';
        code = `${argument0} % ${divisor} == 0`;
    }

    return [code, window.Blockly.JavaScript.javascriptGenerator.ORDER_EQUALITY];
};
